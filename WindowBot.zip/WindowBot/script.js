let isOpen = false;

function toggleWindow() {
  const windowElement = document.getElementById("window");
  const statusText = document.getElementById("status");

  if (isOpen) {
    // Close the window
    windowElement.style.backgroundColor = "#87CEEB"; // sky blue
    statusText.textContent = "Window is Closed";
  } else {
    // Open the window
    windowElement.style.backgroundColor = "#FFFFFF"; // white
    statusText.textContent = "Window is Open";
  }

  isOpen = !isOpen;
}